#!/bin/bash
echo "========================================="
echo "🚀 部署英语学习应用"
echo "========================================="

# 停止现有服务
echo "停止现有服务..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# 创建应用目录
echo "创建应用目录..."
mkdir -p /root/english-learning
cd /root/english-learning

# 安装依赖
echo "安装后端依赖..."
cd backend
npm install --production --silent

# 创建数据库
echo "初始化数据库..."
touch database.sqlite

# 启动服务
echo "启动后端服务..."
pm2 start src/server.js --name english-learning-backend --node-args='--max-old-space-size=512'

# 配置Nginx
echo "配置Nginx..."
cat > /etc/nginx/conf.d/english-learning.conf << 'EOF'
server {
    listen 80;
    server_name _;
    
    # 前端静态文件
    location / {
        root /root/english-learning/frontend;
        try_files $uri $uri/ /index.html;
        index index.html;
    }
    
    # API代理
    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

# 测试并重启Nginx
nginx -t && systemctl restart nginx

echo "========================================="
echo "✅ 部署完成！"
echo "========================================="
echo "🌐 访问地址: http://服务器IP"
echo "🔑 管理员账号: admin / admin123"
echo ""
echo "📊 检查状态:"
pm2 list
echo ""
echo "🌐 端口监听:"
netstat -tlnp | grep -E ':(80|443|3000)'